
% To calculate the mean of histone data by averaging the data of all
% regions in one gene. The regions are denoted by IDs in the first column

function data_mean = func_Histone_mean(data,Ngenes)    
    
    Nhis = size(data,2)-1; % number of histones
    data_mean=zeros(Ngenes,Nhis);  %(Num genes) x (Nhis) HMs
    mrow=size(data,1);

    k=1;
    j=1;

    while(k<=Ngenes)
        i=j;
        v=data(j,1); % id from the first column
        j=j+1;
        while(j<=mrow && data(j,1)==v)
            j=j+1;
        end
        if i==j-1
            data_mean(k,:)=data(i:(j-1),2:end);
        else
            data_mean(k,:)=mean(data(i:(j-1),2:end));
        end
        k=k+1;

    end


end


