
Steps of generating prior based on histone modifications (HMs) data:
(Main function is "Main_generatePriors.m", which includes all the following steps)

1. Extract HMs data for genes of interest.
This step need to done manually. Here we extracted HMs for the nine genes used in our manuscript.

2. Average the HMs data across different loci.
This is done by function "func_Histone_mean", which is called by "func_generate_prior".

3. Calculate the correlation of HMs for pairs of genes, take absolute values of the correlation coefficients, and use them as prior values.
This is done by "func_generate_prior.m"

4. For normalization of prior values (e.g. prior "In"), function "func_norm_prior" is called.

5. Prior "GIn" is obtained by taking average of prior "G" and "In", which are "Genic prior" and "normalized intergenic prior".













