
function prior = func_generate_prior(dataHMs,Ngenes)  

    HMs_mean = func_Histone_mean(dataHMs, Ngenes); 

    % to compare with the corr_matrix in "E:\Chf_G\Test_on_Matlab\yeast9_test\yeast_large_net\main_test_priors_genic_inter.m"
    corr_HMs = corr(HMs_mean'); 
    
    % ----note that "corr"-->"prior": diagonal=0; absolute values
    prior = corr_HMs - diag(diag(corr_HMs));
    prior = abs(prior);

end