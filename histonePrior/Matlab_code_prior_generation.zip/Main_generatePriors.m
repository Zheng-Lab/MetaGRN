
clear;

Ngenes = 9;

genicHMs = importdata('yeast9_histone_genic_data.txt');
interHMs = importdata('yeast9_histone_intergenic_data.txt');
allHMs = importdata('yeast9_histone_data.txt');

genicPrior = func_generate_prior(genicHMs, Ngenes);  % G
interPrior = func_generate_prior(interHMs, Ngenes);  % I
allPrior = func_generate_prior(allHMs, Ngenes);  % A



% normalization by random distribution
rnum = 5000;
norm_interPrior = func_norm_prior(interPrior,rnum,Ngenes);  % In

GIn = (genicPrior + norm_interPrior)/2;



