

function norm_prior = func_norm_prior(Prior,rnum,Ngenes)  

    % normalization by random distribution    
    NN = Ngenes*Ngenes;
    randDistr=1+fix(rand(rnum,1)*NN);

    rDist_prior=Prior(randDistr);
    norm_prior=zeros(Ngenes,Ngenes);
    for i=1:NN
        cnt=size(find(rDist_prior<=Prior(i)),1);
        norm_prior(i)=cnt/rnum;    
    end

end