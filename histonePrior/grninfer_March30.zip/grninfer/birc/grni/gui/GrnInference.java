package birc.grni.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;





public class GrnInference extends GrnInferencePanel{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GrnInference(){
		
		dbnButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				//analysis_.start();
				dbnInference();
			}
		});
		
		rfButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				rfInference();
			}
		});
		
		elasticNetButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					elasticNetInference();
			}
		});
		
		ridgeButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				ridgeRegression();
				
			}
		});
		
		lassoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lassoInference();
		}
	});
	}
	
	public void dbnInference() {
		//JFrame dbnFrame = new JFrame();
		GrnDbn grn_d = new GrnDbn(new JFrame());
		
		grn_d.frame_dbn.setVisible(true);
		
		//dbnFrame.setVisible(true);
	}
	
	public void rfInference() {
		GrnRf grnRf = new GrnRf(new JFrame());
		grnRf.frameRf.setVisible(true);
	}
	
	public void elasticNetInference() {
		GrnElasticNet grnElasticNet = new GrnElasticNet(new JFrame());
		grnElasticNet.frameElasticNet.setVisible(true);
	}
	
	public void ridgeRegression() {
		GrnRidge grnRidge = new GrnRidge(new JFrame());
		grnRidge.frame_ridge.setVisible(true);
	}
	
	public void lassoInference() {
		GrnLasso grnLasso = new GrnLasso(new JFrame());
		grnLasso.frameLasso.setVisible(true);
	}
}
