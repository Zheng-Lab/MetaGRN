package birc.grni.gui;

import org.omegahat.Simulation.MCMC.Examples.*;

import birc.grni.dbn.DynamicBayesianNetwork;
import birc.grni.gui.visulization.GrnVisulizeNetwork;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Window;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.*;

import javax.swing.JFrame;


public class GrnDbn extends GrnDbnDisplay {
	
	//protected JFrame grn_frame;
	private  static String resultPath;
	private static Logger logger = Logger.getLogger(GrnDbn.class.getName());
	protected Binomial_HDBNf hdb ;

	public GrnDbn(JFrame frame_1) {
		super(frame_1);
		
		header_dbn.setTitle("Set parameters for DBN");
		header_dbn.setInfo("Enter parameters and click start button ");
		header_dbn.setTopColor(Color.RED);
		header_dbn.setBottomColor(Color.PINK);
		// TODO Auto-generated constructor stub
		
		// add spinner model to beta
		SpinnerNumberModel spinModel = new SpinnerNumberModel(1, 1, 5, 1);
		betaSpinner.setModel(spinModel);
		
		// add spinner model to iterations
		//SpinnerNumberModel iterModel = new SpinnerNumberModel(150000,100000,300000,25000);
		SpinnerNumberModel iterModel = new SpinnerNumberModel(100000,100000,300000,25000);
		iterationSpinner.setModel(iterModel);
		
		priorDataBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				enablePrior();
			}
		});
		
		startButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				String inputFile = dataFilePathDbn.getText();
				//String s = numGenesDbn.getText();
				//int genes = Integer.parseInt(numGenesDbn.getText());
				//int samples = Integer.parseInt(numTimePoints.getText());
				//String resultPath = resultSavePath.getText();
				//resultPath = resultSavePath.getText();
				logger.log(Level.INFO, "dbn start buttion click");
				startButton.setEnabled(false);
				int iterations =(Integer)iterationSpinner.getModel().getValue();
				boolean select =priorDataBox.isSelected();
				DynamicBayesianNetwork dbn = new DynamicBayesianNetwork(inputFile, iterations);
				if(select){
					int beta =(Integer)betaSpinner.getModel().getValue();
					String priorFile =priorDataText.getText();
					//hdb = new Binomial_HDBNf(genes, inputFile, iterations, beta, priorFile);
					dbn.dbnMcmcWithPrior(beta, priorFile);
					
				}else{
					//hdb = new Binomial_HDBNf(genes, inputFile, iterations);
					dbn.dbnMcmcWithOutPrior();
				}
							
				//hdb.dbnRun();
				//hdb.execute();       
				dbn.execute();		// start swingWorker as a worker thread
				logger.log(Level.INFO, "End of Dbn ");
				//frame_dbn.dispose();
				//logger.log(Level.INFO, "dbn frame closed ");
			}
		});
		
		
	}
	
	private void enablePrior(){
		boolean select =priorDataBox.isSelected();
		priorDataText.setEnabled(select);
		priorSelect.setEnabled(select);
		betaSpinner.setEnabled(select);
	}
	
	public static void evaluateNetwork(int outputNetwork [][], int genes, String resultSavePath){
		/* Actual 9 genes spellman netork is hardcoded here*/
		/* this actual network will compare with output network and generate TP,FP,FN,TN and then
		 * precision , recall and f-measure
		 */
		int actualNetwork [][]= new int [genes][genes];
		
		actualNetwork [0][1] = 1;
		
		actualNetwork [1][3] = 1;
		actualNetwork [1][6] = 1;
		
		actualNetwork [2][0] = 1;
		actualNetwork [2][7] = 1;
		
		actualNetwork [3][5] = 1;
		actualNetwork [3][6] = 1;
		
		actualNetwork [4][0] = 1;
		actualNetwork [4][1] = 1;
		actualNetwork [4][6] = 1;
		actualNetwork [4][7] = 1;
		
		actualNetwork [5][0] = 1;
		actualNetwork [5][7] = 1;
		
		actualNetwork [6][5] = 1;
		
		actualNetwork [7][1] = 1;
		
		actualNetwork [8][5] = 1;
		actualNetwork [8][6] = 1;
		
		int TP =0;
		int FP =0;
		int TN =0;
		int FN =0;
		
		// compare result
		for(int i=0; i<genes; i++){
 		   for(int j=0; j<genes; j++){
 			   if (outputNetwork [i][j]==1 & actualNetwork [i][j] ==1){
 				   TP= TP+1;
 			   }
 			   else if (outputNetwork [i][j]==1 & actualNetwork [i][j] ==0) {
 				   FP = FP+1;
				
 			   }else if (outputNetwork [i][j]==0 & actualNetwork [i][j] ==0) {
 				   TN =TN +1;
				
 			   }else if (outputNetwork [i][j]==0 & actualNetwork [i][j] ==1) {
 				   FN = FN +1;
				
 			   }
 		   }
		}
		
		// calculate precision recall and F-measure
		double precision = (double)TP/(TP+FP);
		double recall = (double)TP/(TP + FN);
		
		double Fmeasure = 2*((precision*recall)/(precision + recall));
		
		// write results
		try {
			PrintStream printer = new PrintStream(new File(resultSavePath));
			
			/* print results */
			printer.printf("TP = " + TP + "\n");
			printer.printf("FP = " + FP + "\n");
			printer.printf("TN = " + TN + "\n");
			printer.printf("FN = " + FN + "\n");
			printer.printf("Precision = " + precision + "\n");
			printer.printf("Recall = " + recall + "\n");
			printer.printf("F-measure = " + Fmeasure + "\n");
			
			printer.printf( "\n");
			printer.printf( "\n");
			
			printer.printf( "Print output network as a matrix" +"\n");
			// print output network as a matrix // 
			for(int i=0; i<genes; i++){
		    		   for(int j=0; j<genes; j++){
		    			   
		    			   if(outputNetwork[i][j] == 1){
		    				   printer.printf("1" + "\t");
		                       
		    			   }
		    			   else{
		    				   printer.printf("0" + "\t");
		    			   }
		    		   }
		    		 
		    		   printer.printf("\n");
		     }
		    	  
				   
			
			printer.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public static void dbnResultPrinter(int network [][], int genes){
		
		Object [] options = {"Save Result" , "Visualize Result"};
		int optionValue = JOptionPane.showOptionDialog(null, "What do you like to do for the results?", "Inference Result", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[1]);
		
		if(optionValue == JOptionPane.OK_OPTION){
			// save result
			JFileChooser chooser = new JFileChooser();
		    int returnVal = chooser.showSaveDialog(null);
		    if(returnVal == JFileChooser.APPROVE_OPTION) {
		    	String resultSavePath = chooser.getSelectedFile().getAbsolutePath();
		    	evaluateNetwork(network, genes, resultSavePath);
		    	//try {
		    		
					//FileWriter resultFileWriter = new FileWriter(resultSavePath , true);
		    		
					// write results as a matrix // 
				/*	for(int i=0; i<genes; i++){
			    		   for(int j=0; j<genes; j++){
			    			   
			    			   if(network[i][j] == 1){
			    				   resultFileWriter.write("1" + "\t");
			                       
			    			   }
			    			   else{
			    				   resultFileWriter.write("0" + "\t");
			    			   }
			    		   }
			    		 
			    		   resultFileWriter.write("\n");
			    	   }
			    	  
					   resultFileWriter.write("\n");
					   resultFileWriter.write("\n");   */
			    	      
			    	   // write results according to standard format 
		    			/*PrintStream printer = new PrintStream(new File(resultSavePath));
					   for(int m=0; m<genes; m++){
			    		   for(int n=0; n<genes; n++){
			    			   
			    			   if(network[m][n] == 1){
			    				  // resultFileWriter.write("G" + (m+1) + "\t" + "G" + (n+1) + "\t" + 1);
			    				   printer.print("G" + (m+1) + "\t" + "G" + (n+1) + "\t" + 1);
			                       
			    			   }
			    			   else{
			    				  // resultFileWriter.write("G" + (m+1) + "\t" + "G" + (n+1) + "\t" + 0);
			    				   printer.print("G" + (m+1) + "\t" + "G" + (n+1) + "\t" + 0);
			    			   }
			    			  // resultFileWriter.write("\n");
			    			   printer.printf("\n");
			    			   
			    		   }
			    	   }
					 //  resultFileWriter.close();
					   printer.close(); */
				//} catch (IOException e) {
					// TODO Auto-generated catch block
				//	e.printStackTrace();
				//}		
		    }  	
		} 
		
		if(optionValue == JOptionPane.NO_OPTION){
			logger.log(Level.INFO, "visualization has selected");
			// create a visualization class object and pass the network
			try {
				GrnVisulizeNetwork visualization = new GrnVisulizeNetwork(network, genes);
			} catch (Exception e) {
				logger.log(Level.SEVERE, "exception has thrown - " + e.toString());
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		startButton.setEnabled(true);
	}
						
	
}
