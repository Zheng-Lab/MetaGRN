package birc.grni.gui.visulization;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import ch.epfl.lis.gnwgui.IONetwork;
import ch.epfl.lis.gnwgui.NetworkElement;
import ch.epfl.lis.imod.ImodNetwork;
import ch.epfl.lis.networks.ios.ParseException;


public class GrnVisualDisplay extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected JLabel inputFileLabel;
	protected TextField inputTextField;
	protected JButton chooseButton;
	protected JButton generateNetworkButton;

	private String filepath;
	private NetworkElement element;
	
	public GrnVisualDisplay() {
		
		super();

		this.setLayout(new GridLayout(3,1,5,5));
		
		JPanel emptyPanel = new JPanel(new FlowLayout());
		JPanel upPanel = new JPanel(new FlowLayout());
		JPanel lowPanel = new JPanel(new FlowLayout());
		
		this.setName("visulizationPanel");

		inputFileLabel = new JLabel("Upload a file:  ");
		inputTextField = new TextField("upload the file for network visulization:   ");
		chooseButton = new JButton("Choose");
		chooseButton.addActionListener(
				new ActionListener(){
					public void actionPerformed(ActionEvent e){
						/* pop up the file chooser window*/
						JFileChooser chooser = new JFileChooser();
					    int returnVal = chooser.showOpenDialog(null);
					    if(returnVal == JFileChooser.APPROVE_OPTION) {
					    	filepath = chooser.getSelectedFile().getAbsolutePath();
					    	inputTextField.setText(chooser.getSelectedFile().getAbsolutePath());
		
					    	URL inputfileURL = null;
							
							try {
								inputfileURL = new File(filepath).toURI().toURL();
							} catch (MalformedURLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							
							String networkName = "Network Name";	

							try {
								element = IONetwork.loadItem(networkName, inputfileURL, ImodNetwork.TSV);
							} catch (FileNotFoundException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (ParseException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (Exception e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
	
					    }
						
					}
				}
	);
		
		generateNetworkButton = new JButton("generate network");
	
		lowPanel.add(generateNetworkButton);
		
		upPanel.add(inputFileLabel);
		upPanel.add(inputTextField);
		upPanel.add(chooseButton);
		lowPanel.add(generateNetworkButton);
		this.add(emptyPanel);
		this.add(upPanel);
		this.add(lowPanel);
		
		generateNetworkButton.addActionListener(
				new ActionListener(){
					public void actionPerformed(ActionEvent e) {
					GrnGraphViewerWindow window = new GrnGraphViewerWindow(new JFrame(), element);	
					}
				}
		);

	}

	public String getFilepath() {
		return filepath;
	}

	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
	
	public NetworkElement getElement() {
		return element;
	}

	public void setElement(NetworkElement element) {
		this.element = element;
	}

}


	

