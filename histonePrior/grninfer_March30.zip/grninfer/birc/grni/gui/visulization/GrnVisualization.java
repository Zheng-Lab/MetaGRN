package birc.grni.gui.visulization;


public class GrnVisualization extends GrnVisualDisplay{

	private static final long serialVersionUID = 1L;

	public GrnVisualization() {

	}

}
