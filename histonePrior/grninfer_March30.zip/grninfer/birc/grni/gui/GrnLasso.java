package birc.grni.gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import birc.grni.en.*;

public class GrnLasso extends GrnLassoDisplay
{	
	public GrnLasso(JFrame frame)
	{
		super(frame);
		
		headerLasso.setTitle("Select Input Data File for Lasso");
		headerLasso.setInfo("After selecting input data file, click start button");
		headerLasso.setTopColor(Color.RED);
		headerLasso.setBottomColor(Color.PINK);
		
		startButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String inputFilePath = dataFilePathField.getText();
				
				try
				{
					/* run algorithm*/
					//TEST
					//double[][] VIM = Genie3Time.run(inputFilePath, treeMethod, nbTrees);
					
					//TEST
					/* initialize the algorithm and progress bar*/
					Lasso lasso = new Lasso(inputFilePath);
					lasso.init();
					
					/* run the algorithm*/
					lasso.execute();
					
					//TEST
//					if(JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(null, "Do you want to save the result?", "Save Result", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null))
//					{
//						/* pop up the file chooser window*/
//						JFileChooser chooser = new JFileChooser();
//					    int returnVal = chooser.showSaveDialog(null);
//					    if(returnVal == JFileChooser.APPROVE_OPTION) {
//					    	String resultSavePath = chooser.getSelectedFile().getAbsolutePath();
//					    	/* write result into the file indicated by resultSavePath*/
//							PrintStream resultFilePrinter = new PrintStream(new File(resultSavePath));
//							for(int i = 0; i< VIM.length; i++)
//							{
//								for(int j = 0; j< VIM[0].length; j++)
//									resultFilePrinter.printf("%4.0f", VIM[i][j]);
//								resultFilePrinter.printf("\n");
//							}
//							resultFilePrinter.close();
//					    }
//					}
				}
				catch (Exception exception)
				{
					exception.printStackTrace();
				}
			}
		});
		
		//TEST
//		exitButton.addActionListener(new ActionListener() {
//			
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				//System.exit(0);
//				frameRf.dispose();
//			}
//		});
	}
}
