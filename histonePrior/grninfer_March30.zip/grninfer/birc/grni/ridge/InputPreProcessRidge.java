package birc.grni.ridge;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;


public class InputPreProcessRidge {
	
	double [][] xData;
	double [][] yData;
	double [][] zeroMeanXdata; 
	double [][] zeroMeanYdata;
	int numGeneInFile;
	int numSamplesInFile;
	
	
	public void processInput(String filePath) throws FileNotFoundException , IOException{
		
			ArrayList<ArrayList<Double>> expressArray = new ArrayList<ArrayList<Double>>();
			FileReader fr = new FileReader(filePath);
			BufferedReader br = new BufferedReader(fr);
			
			String line = "";
			while((line=br.readLine()) != null){
				ArrayList <Double> lineArray = new ArrayList<Double>();
				Scanner sc =new Scanner(line);
				while(sc.hasNext()){
					lineArray.add(sc.nextDouble());
				}
				expressArray.add(lineArray);
				sc.close();
			}
			br.close();
			numSamplesInFile= expressArray.size();
			numGeneInFile = expressArray.get(0).size();
			double [][] expressionData = new double [numSamplesInFile][numGeneInFile];
			for(int i=0 ;i<numSamplesInFile;i++){
				for(int j=0;j<numGeneInFile;j++){
					expressionData[i][j]=expressArray.get(i).get(j);
				}
			}
			dataSeparation(expressionData);
			zeroMeanXdata = zeroMean(xData);
			zeroMeanYdata = zeroMean(yData);
			
			
			
	}
	
	public void dataSeparation(double [][] data){
		int samples = data.length;
		int numGene = data[0].length;
		 xData = new double[samples-1][numGene];
		 yData = new double[samples-1][numGene];
		for(int i=0;i<samples-1;i++){
			for(int j=0;j<numGene;j++){
				xData[i][j]=data[i][j];
				yData[i][j] =data[i+1][j];
			}
		}
		
	}
	
	public double [][] zeroMean(double [][] data){
		int row = data.length;
		int col = data[0].length;
		double [][] normalizeData= new double [row][col];
		double [] colArray = new double[row];
		for(int colvalue=0;colvalue<col;colvalue++){
			for(int i=0;i<row;i++){
				colArray[i]=data[i][colvalue]; 
			}
			for(int rowvalue=0;rowvalue<row;rowvalue++){
				double meanColumn = RidgeStat.mean(colArray);
				double stdColumn  = RidgeStat.unbiasedStd(colArray);
				normalizeData [rowvalue][colvalue] = (data[rowvalue][colvalue] - meanColumn)/(Math.sqrt(row -1)*stdColumn); 
			}
		}
		return normalizeData;
	}

}

