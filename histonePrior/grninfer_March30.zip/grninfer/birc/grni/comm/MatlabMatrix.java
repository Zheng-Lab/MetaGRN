package birc.grni.comm;

//TODO: MatlabMatrix
/**
 * vector and matrix structure used in matlab
 * 
 * @author liu xingliang
 */
public class MatlabMatrix {

}
