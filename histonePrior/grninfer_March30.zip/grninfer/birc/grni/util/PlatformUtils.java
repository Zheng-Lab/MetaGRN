package birc.grni.util;

/**
 * platform-related utility functions
 * 
 * @author liu xingliang
 */
public class PlatformUtils {
	
	//TODO: PlatformUtils.platform
	/**
	 * detect the platform
	 * @return
	 */
	public static String platform() {
		return "";
	}
}
