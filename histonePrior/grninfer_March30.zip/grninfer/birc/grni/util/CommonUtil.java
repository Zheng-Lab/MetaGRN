package birc.grni.util;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Random;


public class CommonUtil {
	
	/**
	 * generate random double matrix
	 * @param rows
	 * @param columns
	 * @return
	 */
	public static ArrayList<ArrayList<Double>> randn(int rows, int columns){
		
		/* random matrix*/
		ArrayList<ArrayList<Double>> randomMatrix = new ArrayList<ArrayList<Double>>();
		
		/* generate random matrix*/
		Random random = new Random();
		for(int i = 0; i< rows; i++) {
			ArrayList<Double> oneRow = new ArrayList<Double>();
			for(int j = 0; j< columns; j++) {
				oneRow.add(2*random.nextDouble()-1); /* between -1 and 1*/
			}
			randomMatrix.add(oneRow);
		}
		
		return randomMatrix;
	}
	
	/**
	 * generate random float (single) matrix
	 * @param rows
	 * @param columns
	 * @return
	 */
	public static ArrayList<ArrayList<Float>> randnSingle(int rows, int columns){
		
		/* random matrix*/
		ArrayList<ArrayList<Float>> randomMatrix = new ArrayList<ArrayList<Float>>();
		
		/* generate random matrix*/
		Random random = new Random();
		for(int i = 0; i< rows; i++) {
			ArrayList<Float> oneRow = new ArrayList<Float>();
			for(int j = 0; j< columns; j++) {
				oneRow.add(2*random.nextFloat()-1); /* between -1 and 1*/
			}
			randomMatrix.add(oneRow);
		}
		
		return randomMatrix;
	}
	
	/**
	 * Validate number of input arguments and return an appropriate error message
	 * @param low
	 * @param high
	 * @param n
	 * @return
	 */
	public static String nargchk(int low, int high, int n) {
		if(n < low)
			return "Not enough input arguments.";
		else if(n > high)
			return "Too many input arguments.";
		else
			return "";
	}
	
	/**
	 * 
	 * @param low
	 * @param high
	 * @param n
	 * @param returnType
	 * @return
	 */
//	public static Object nargchk(int low, int high, int n, String returnType) {
//		if(returnType.equalsIgnoreCase("string"))
//			return nargchk(low, high, n);
//		else if(returnType.equalsIgnoreCase("struct")) {
//			if (n < low)
//				return new MessageStruct("0", "Not enough input arguments.");
//			else if (n> high)
//				return new MessageStruct("1", "Too many input arguments.");
//			else
//				return new MessageStruct();
//		}
//		else {
//			System.out.println("No such return type in nargchk.");
//			return null;
//		}
//	}
	
	/**
	 * print the error message
	 */
	public static void error() {
		
	}
	
	/**
	 * Return a list of numbers from @param low to @param high (both inclusive)
	 * @param low
	 * @param high
	 * @return
	 */
	public static ArrayList<Integer> range(int low, int high) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		for(int i=low;i<=high;i++) {
			list.add(i);
		}
		return list;
	}
	
	/**
	 * transfer a double precision vector to a single precision one
	 * @param doubleVector an ArrayList object contains the double precision vector
	 * @return
	 */
	public static ArrayList<Float> doubleToSingleVector(ArrayList<Double> doubleVector) {
		ArrayList<Float> singleVector = new ArrayList<Float>();
		for(Double dNumber : doubleVector)
			singleVector.add((dNumber.floatValue()));
		return singleVector;
	}
	
	/**
	 * transfer a double precision vector to a single precision one
	 * @param doubleVector a real array, can use basic type(int, float, double, long) elements
	 * @return
	 */
	public static float[] doubleToSingleVector(double[] doubleVector, int length) {
		float[] singleVector = new float[length];
		for(int i = 0;i < length; i++)
			singleVector[i] = (float) doubleVector[i];
		return singleVector;
	}
	
	/**
	 * transfer a double precision matrix to a single precision one
	 * @param doubleMatrix
	 * @return
	 */
	public static ArrayList<ArrayList<Float>> doubleToSingleMatrix(ArrayList<ArrayList<Double>> doubleMatrix) {
		ArrayList<ArrayList<Float>> singleMatrix = new ArrayList<ArrayList<Float>>();
		for(ArrayList<Double> doubleOneRow : doubleMatrix) {
			singleMatrix.add(doubleToSingleVector(doubleOneRow));
		}
		return singleMatrix;
	}
	
	public static float[][] doubleToSingleMatrix(double[][] doubleMatrix, int row, int column) {
		float[][] singleMatrix = new float[row][];
		for(int i = 0; i< row; i++)
			singleMatrix[i] = doubleToSingleVector(doubleMatrix[i], column);
		return singleMatrix;
	}
	
	/**
		return a double precision matrix of all zeros
		@param row
		@param column
		@return double precision matrix of all zeros
	 */
	public static double[][] zeros(int row, int column)
	{
		double[][] zeroMatrix = new double[row][column];
		for(int i = 0; i< row; i++)
			for(int j = 0; j< column; j++)
				zeroMatrix[i][j] = 0;
			
		return zeroMatrix;
	}
	
	/**
		return a double precision matrix of all ones
		@param row
		@param column
		@return double precision matrix of all zeros
	*/
	public static double[][] ones(int row, int column)
	{
		double[][] zeroMatrix = new double[row][column];
		for(int i = 0; i< row; i++)
			for(int j = 0; j< column; j++)
				zeroMatrix[i][j] = 1;
			
		return zeroMatrix;
	}
	
	public static ArrayList<ArrayList<Double>> zeroMean(ArrayList<ArrayList<Double>> matrix)
	{
		int row = matrix.size();
		int column = matrix.get(0).size();
		ArrayList<ArrayList<Double>> resultMatrix = new ArrayList<ArrayList<Double>>();
		for(int i = 0; i< row; i++)
			for(int j = 0; j< column; j++)
			{
				// jth (j start from 0) column
				ArrayList<Double> oneColumn = new ArrayList<Double>();
				for(int k = 0; k< row; k++)
					oneColumn.add(matrix.get(k).get(j));
				resultMatrix.add(new ArrayList<Double>());
				resultMatrix.get(i).add(
						(matrix.get(i).get(j) - Statistic.meanDoubleArrayList(oneColumn)) / (Math.sqrt(row-1) * Statistic.unbiasedStdDoubleArrayList(oneColumn))
					);
			}
		return resultMatrix;
	}
	
	public static double[][] zeroMean(double[][] matrix)
	{
		int row = matrix.length;
		int column = matrix[0].length;
		double[][] resultMatrix = new double[row][column];
		for(int i = 0; i< row; i++)
			for(int j = 0; j< column; j++)
			{
				// jth (j start from 0) column
				ArrayList<Double> oneColumn = new ArrayList<Double>();
				for(int k = 0; k< row; k++)
					oneColumn.add(matrix[k][j]);
				resultMatrix[i][j] = (matrix[i][j] - Statistic.meanDoubleArrayList(oneColumn)) / (Math.sqrt(row-1) * Statistic.unbiasedStdDoubleArrayList(oneColumn));
			}
		return resultMatrix;
	}
	
	public static void copyFile(File source, File dest) throws IOException {
	    InputStream is = null;
	    OutputStream os = null;
	    try {
	        is = new FileInputStream(source);
	        os = new FileOutputStream(dest);
	        byte[] buffer = new byte[1024];
	        int length;
	        while ((length = is.read(buffer)) > 0) {
	            os.write(buffer, 0, length);
	        }
	    } finally {
	        is.close();
	        os.close();
	    }
	}
	
	/**
	 * copy all dependent libraries used by our own native libraries into correct location
	 */
	public static void copyDependentLibs() {
		//TEST
		URL dependentLibsFolderURL = Class.class.getClass().getResource(GLOBALVAR.dependentLibsFolder);
		//URL dependentLibsFolderURL = GrnGuiMain.class.getClass().getResource(GLOBALVAR.dependentLibsFolder);
		
		FileUtils.copyResourcesRecursively(dependentLibsFolderURL, new File("."));
	}
	
	/**
	 * Load dll from jar, first copy the dll file into a temp file out of jar,
	 * then, access it using absolute path in System.load() method
	 * @param relativePath dll file path relative to the classpath
	 * @throws IOException
	 */
	public static void loadJarNativeLib(String relativePath) {
	    try
	    {
	    	//TEST
	    	java.io.InputStream in = Class.class.getClass().getResourceAsStream(relativePath);
			//java.io.InputStream in = GrnGuiMain.class.getClass().getResourceAsStream(relativePath);
		    
	    	byte[] buffer = new byte[1024];
		    int read = -1;
		    /* extract the dll file name*/
		    File dllFile = new File(relativePath);
		    String prefix = dllFile.getName();						
		    File temp = File.createTempFile(prefix, "");			/* prefix of the temp file is the original dll file name*/
		    
		    /* copy the original dll file into temp file*/
		    java.io.FileOutputStream fos = new FileOutputStream(temp);
		    while((read = in.read(buffer)) != -1) {
		        fos.write(buffer, 0, read);
		    }
		    fos.close();
		    in.close();
		    
		    /* load temp file as dll*/
		    System.load(temp.getAbsolutePath());
		    
		    /* 
		     * the following code is used to delete temp files left by last time use of our program.
		     * Since after termination of our program, the temp file is still in use (Q: loaded by System.load() and haven't been released),
		     * File.deleteOnExit() won't work for the temp file.
		     * */
			final String libraryPrefix = prefix;
			final String lockSuffix = ".lock";
	
			/* create lock file */
			final File lock = new File(temp.getAbsolutePath() + lockSuffix);
			lock.createNewFile();
			lock.deleteOnExit();
	
			/* file filter for library file (without .lock files) */
			FileFilter tmpDirFilter = new FileFilter() {
				public boolean accept(File pathname) {
					return pathname.getName().startsWith(libraryPrefix)
							&& !pathname.getName().endsWith(lockSuffix);
				}
			};
	
			/* get all library files from temp folder */
			String tmpDirName = System.getProperty("java.io.tmpdir");
			File tmpDir = new File(tmpDirName);
			File[] tmpFiles = tmpDir.listFiles(tmpDirFilter);
	
			/* delete all files which don't have an accompanying lock file which is left by last time use of our program*/
			for (int i = 0; i < tmpFiles.length; i++) {
				/* Create a file to represent the lock and test. */
				File lockFile = new File(tmpFiles[i].getAbsolutePath() + lockSuffix);
				if (!lockFile.exists()) {
					//System.out.println("deleting: " + tmpFiles[i].getAbsolutePath());
					tmpFiles[i].delete();
				}
			}
	    }
	    catch(IOException e)
	    {
	    	e.printStackTrace();
	    }
	}

}
