package birc.grni.util;

public class GLOBALVAR {
	
	public static final String dependentLibsFolder = "/deplibs";	/* folder of dependent libraries used by our own libs*/
	public static final String inputDataFolder = "data";			/* folder of input data file*/
	public static final String nativeLibFolder = "/nativelib";		/* folder of native library file(.dll, .so, and so on)*/
	public static final String resourceFolder = "/resource";		/* folder of all resources, for example, pictures*/
	public static final String resourcePictureFolder = "picture";	/* folder of picture resources, used together with "resourceFolder" variable*/
}
