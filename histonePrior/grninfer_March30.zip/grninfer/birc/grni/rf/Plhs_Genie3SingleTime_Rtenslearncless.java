package birc.grni.rf;
public class Plhs_Genie3SingleTime_Rtenslearncless {
	private TreeEnsembleStruct[][] treeEnsemble;
	private double[][] varimp;
	
	public TreeEnsembleStruct[][] getTreeEnsemble() {
		return this.treeEnsemble;
	}
	public double[][] getVarimp() {
		return this.varimp;
	}
}
