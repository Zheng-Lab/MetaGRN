package birc.grni.rf;
public class GlobalVar
{
	public static double[][] XTS;
	public static TreeStruct tree;
	public static double[][] assignednodets;
}