package birc.grni.rf;
class RtEnsParam {
	private int nbTerms;
	private int bootStrap;
	private int mart=-1;
	private float martmu=-1.0f;
	private RtParam rtParam;
	
	public int getNbTerms() {
		return nbTerms;
	}
	public void setNbTerms(int nbTerms) {
		this.nbTerms = nbTerms;
	}
	public int getBootStrap() {
		return bootStrap;
	}
	public void setBootStrap(int bootStrap) {
		this.bootStrap = bootStrap;
	}
	public RtParam getRtParam() {
		return rtParam;
	}
	public void setRtParam(RtParam rtParam) {
		this.rtParam = rtParam;
	}
	public void setMart(int mart) {
		this.mart = mart;
	}
	public int getMart() {
		return this.mart;
	}
	public void setMartmu(float martmu) {
		this.martmu = martmu;
	}
	public float getMartmu()
	{
		return this.martmu;
	}
}
