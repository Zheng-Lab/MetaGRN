package birc.grni.rf;
import java.util.*;
import java.io.*;

public class RFTimeSeries {
	public static void rfTimeSeries() throws IOException, FileNotFoundException {
		/* read input data from file*/
		String exprMatrixFilePath = "";
		BufferedReader brExprMatrixFile = new BufferedReader(new FileReader(exprMatrixFilePath));
		
		ArrayList<ArrayList<Double>> exprMatrix = new ArrayList<ArrayList<Double>>();	/* time series data*/
		String oneLine = "";
		while((oneLine = brExprMatrixFile.readLine())!=null){
			ArrayList<Double> oneLineArray = new ArrayList<Double>();
			Scanner scanner = new Scanner(oneLine);
			while(scanner.hasNext())
				oneLineArray.add(scanner.nextDouble());
			exprMatrix.add(oneLineArray);
		}
		
		
	}
}